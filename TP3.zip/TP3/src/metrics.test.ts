import {expect} from 'chai'

const a: number = 0

describe('Metrics', function () {
	describe('#get', fucntion(){
		it('should equal 0', function () {
			expect(a).to.equal(1)
		})
	})
})